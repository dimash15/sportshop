<?php 
echo '<pre style="word-wrap: break-word; white-space: pre-wrap;">
User-Agent: *  
Disallow: /admin/  
Disallow: /cart  
Disallow: /cart/  
Disallow: /checkout  
Disallow: /entrance  
Disallow: /registration  
Disallow: /profile  
Disallow: /cabinet  
Disallow: /login  
Disallow: /logout 
Disallow: /recovery 

Sitemap: http://shoptest.kl.com.ua/sitemap.xml
</pre> '
?>   