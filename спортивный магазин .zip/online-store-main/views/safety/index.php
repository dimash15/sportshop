<?php require_once ROOT . "/views/header/header.php";  ?> 
<main>
	
	<div class="wrap_about_content">
		<div class="content">
		<h1 class="about_title">Политика конфиденциальности</h1>
		<div class="about_content_body"><?= $info['text'] ?></div>	
		</div> <!-- content -->
	</div> <!-- wrap_about_content -->

</main>
<?php require_once ROOT . "/views/footer/footer.php";  ?> 
 