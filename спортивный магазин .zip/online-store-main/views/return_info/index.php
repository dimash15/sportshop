<?php require_once ROOT . "/views/header/header.php";  ?> 
<main>
<div class="wrap_about_content">
		<div class="content">
		<h1 class="about_title">Возврат товара</h1>
		<div class="return_content_body"><?= $info['text'] ?></div>	 

</main>
<?php require_once ROOT . "/views/footer/footer.php";  ?> 
 