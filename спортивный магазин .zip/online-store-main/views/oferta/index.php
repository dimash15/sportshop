<?php require_once ROOT . "/views/header/header.php";  ?> 
<main>
	
<div class="wrap_about_content">
	<div class="content">
		<h1 class="about_title">Договор публичной оферты</h1>
		<div class="oferta_content_body"><?= $info['text'] ?></div>	
	</div> <!-- content -->
</div> <!-- wrap_about_content -->	 

</main>
<?php require_once ROOT . "/views/footer/footer.php";  ?> 
 