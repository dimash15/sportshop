<?php
echo 'acces denied';
exit;
?>