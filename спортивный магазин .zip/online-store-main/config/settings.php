<?php
$settings =  array(
	"db_address" => "localhost",
	"db_name" => " ",
	"db_user" => " ",
	"db_pass" => " ",
	"login_tries" => 3,
);


?>